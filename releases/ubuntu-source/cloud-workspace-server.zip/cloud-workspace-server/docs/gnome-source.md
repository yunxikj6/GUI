# 原版 Ubuntu 桌面的云端绘图源

GNOME Shell 46、Mutter、Ubuntu Dock、Yaru 与 Noble 壁纸运行在云机。源端把这个 GNOME Shell 进程发出的 Mesa 绘图命令和绘图资源交给私有中继。客户端用自己的渲染器绘制本地窗口。原桌面的 GPU 回读留在云机，独立事件管道只返回完整显示帧的序号与 SHA-256。

## 云端环境与启动

在云端的 Ubuntu 24.04 amd64 普通用户环境安装发行版组件。需要 Python 3、`ubuntu-session`、`gnome-shell`、`gnome-shell-extension-ubuntu-dock`、`yaru-theme-gnome-shell`、`yaru-theme-icon`、`ubuntu-wallpapers-noble`、`fonts-noto-cjk`、`xvfb`、`x11-utils`、`xdotool`、`dbus-daemon`、`libglib2.0-bin`、`libgl1-mesa-dri` 和提供 `virgl_test_server` 的 `virgl-server`。使用有完整依赖的专用虚拟机或容器，保留系统 GLib 的 `gio-launch-desktop` 程序。源端需要可写的私有临时目录、独立的进程及套接字环境。新启动的源使用独立的 HOME、桌面目录、Xauthority 和两条 D-Bus 总线。

用户通过配对中继打开云桌面。在仓库根目录运行以下命令启动云机回环服务。交互式终端会显示配对码。在服务管理器内运行时，用其私密环境配置设置 `CLOUDWORKSPACE_GNOME_TOKEN`。

```sh
python3 -m cloud_render.gnome_relay --port 17325
```

源进程默认启动发行版的 `ubuntu` 模式，等待 Shell 完成启动、Ubuntu Dock 报告已启用，并收到启动清屏后的真实桌面画面。仅诊断普通 GNOME 运行环境时才显式选用 `--session-mode gnome`。

## 进程接口

中继启动子进程 `python3 -m cloud_render.gnome_source --event-fd N`，继承一个编号至少为 3 的独立可写文件描述符，并将 stdin、stdout 接至管道。三条通道均属于此次专用会话。

| 通道 | 内容 |
| --- | --- |
| stdout | 由首个上下文建立请求开始的完整 Mesa vtest 0 命令、着色器及原始纹理资源。 |
| stdin | 每个动作一条定长记录。首字节 `S` 对应 Super，`M`、`L`、`R` 后跟网络字节序的两个无符号 16 位桌面坐标，分别表示移动、左击和右击。`K` 后跟一个导航键编号。 |
| 事件 FD | 一行一个 JSON 对象。`frame` 提供从 1 开始的 `sequence` 和完整 BGRX 显示面的 `sha256`。`ready` 提供 `width`、`height`、`frames`。`input` 提供成功交给原窗口的输入 `sequence` 以及注入前最后一个绘制序号 `framesBefore`。`unavailable` 提供 `application`，取值为 `chatgpt`、`claude`、`wayland`。 |

当前默认画面 800×520。输入来源调用 `cloud_render.gnome_input.encode_pointer` 与 `encode_key` 进行边界和编号校验。导航键包括 Tab、Shift+Tab、Enter、Escape、四向键、Backspace、Delete、Home、End、PageUp、PageDown 和 Space。每次投递前后，源端都会检查私有 X 显示器上真实 GNOME Shell 窗口的身份与焦点。

云端绘制与中继发送使用独立线程，队列按原顺序保存命令及提交边界。每次会话的排队数据最多 96 MiB，达到上限后由接收速度控制云端后续绘制。源端通过内核提供的对端 PID 和可执行文件身份核对专属 Shell，并在发布前封住外部 Wayland 连接入口。原版 Shell 可直接绘制后台、顶栏、Dock、概览和发行版自带的桌面组件。系统安装的应用启动项保留原有名称、翻译、图标和动作，普通应用的激活请求交回中继。应用自己的绘图适配尚未接合时，调用方收到 `unavailable`。ChatGPT 的独立原版绘图入口可以显示当前支持的已签出流程。[原版应用绘图说明](thin-client.md)

关闭控制管道会结束专有会话，释放该会话的进程及临时状态。新连接从新桌面和完整绘图上下文开始。

```sh
python3 -m unittest discover -s tests -p 'test_gnome_*.py'
```


### 本地重绘 Ubuntu 壁纸

Windows 客户端会在内存中核对随包附带的 Noble 默认壁纸。只有已核对的本机资源才会参与会话协商。云端遇到与该资源字节完全一致的纹理上传时，可发回资源摘要和原始绘图参数。本机据此恢复 Ubuntu 的完整纹理，继续执行原版 GNOME 绘图。旧服务端、缺少该资源的客户端和其他壁纸继续使用原来的绘图指令。

`thin_client/vendor/ubuntu-noble/wallpaper.rgb.xz` 是 Canonical 的 `warty-final-ubuntu.png` 转存为无损 RGB 后的压缩文件。发行版标注版权为 2016–2022 Canonical Ltd，许可为 CC BY-SA 4.0。原包声明及许可全文见 [COPYRIGHT](../thin_client/vendor/ubuntu-noble/COPYRIGHT)。

### GNOME 概览搜索的输入法

打开概览，点击原版 GNOME 搜索框。客户端和云端都支持文字输入时，Windows 输入法在本机处理候选词。提交的文字进入当前这一次获得焦点的 GNOME 搜索框。云端的 GNOME Shell 通过 Clutter 输入法更新自己的控件、搜索结果和画面。中文字体由云机的 `fonts-noto-cjk` 包提供。

云端源码须包含 `cloud_render/gnome_search/`。会话在专用临时 HOME 启用自带的 GNOME Shell 46 输入扩展，校验私有 Unix 套接字对端的 Shell 进程，并监听原版搜索框的焦点。离开概览、锁屏、切换控件或重连都会使先前的候选词提交失效。单次提交接受最多 4096 个 UTF-8 字节的单行文字。私有中转重试复用同一个操作序号。与旧版连接时，原有指针和导航键仍然可用。

实测时，原控件依次显示 `abc`、`abc你好` 和退格后的 `abc你`。独立渲染器输出的 91 帧都与对应的云端原帧哈希相同。[本地重绘画面](gnome-search-zh.png) · [验收记录](measurements/gnome-search-input.json)

支持全选的客户端和云端会协商该操作。按 Ctrl+A 后，云端从当前原厂搜索框核对选区的两端。再次输入会替换选中的文字。移动到其他控件后，此前的焦点编号即失效。

新版会话还可协商带焦点编号的 Backspace 和 Delete。云端在收到按键时核对同一个原始编辑控件，并调用 Clutter 自带的向前或向后删除绑定。原始缓冲区确认实际删除的字符数；光标位于相应边界时保留原文。已经协商该能力的会话会拒绝缺少焦点编号的删除。

### 断开后的本机绘制

Windows 客户端在内存保留从会话开始到最后一次成功显示的原版 GNOME 指令。断开后窗口转为只读，停止发送输入，在新的本机 OpenGL 上下文中重画。只有尺寸与最后一次显示一致、像素摘要也一致时才更新窗口。指令保留上限为压缩数据 24 MiB、原始数据 256 MiB，另有用于编解码的工作缓冲。较长会话达到任一上限时会释放指令缓存，断开后由 Win32 绘制最近一次完成的本机画面。关闭窗口即释放该会话。

在一次真实 InstaBox 桌面指令记录上，Win64 测试移除了源文件，主动把窗口清为全黑，并由另一个进程读取窗口。重新建立本机绘图上下文后，97 帧的摘要与云端全部一致。最后显示的 416,000 个 RGB 像素与断开前逐个相同。[断线重绘测量](measurements/gnome-local-redraw.json)
