@echo off
setlocal
if not defined PROCESSOR_ARCHITECTURE exit /b 2
set "python=%~dp0windows\runtime\python.exe"
if not "%~1"=="" goto arguments
"%python%" -m experiments.original_desktop --instabox
goto finished
:arguments
"%python%" -m experiments.original_desktop %*
:finished
set "code=%ERRORLEVEL%"
if not "%code%"=="0" pause
exit /b %code%
